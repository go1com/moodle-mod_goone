"use strict";

var ScormPackage_Value = {
    "token": "iamatestingtoken12345",
    "version": "1.2",
    "id": 9999
};
